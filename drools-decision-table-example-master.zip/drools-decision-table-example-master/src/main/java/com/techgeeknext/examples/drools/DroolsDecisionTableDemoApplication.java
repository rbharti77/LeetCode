package com.techgeeknext.examples.drools;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DroolsDecisionTableDemoApplication {

    public static void main(String[] args) {
        SpringApplication.run(DroolsDecisionTableDemoApplication.class, args);
    }

}
